import domain.Coordinates;
import domain.Packet;
import domain.ProtocolCodes;
import domain.Task;
import utils.PacketUtils;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Client {
    private static Socket socket;
    private static final Logger logger = Logger.getLogger(Client.class.getName());
    private static ObjectOutputStream output;
    private static ObjectInputStream input;

    public static void main(String[] args) {
        if (args.length == 0) {
            logger.log(Level.SEVERE, "Server IP address or DNS name is required as an argument.");
            return;
        }

        if (!PerformSetup(args) || !ClientHandshake(args)) return;

        while (true) {
            while (true) {
                Packet packet = PacketUtils.ReceivePacket(input);
                if (packet == null) {
                    System.out.println("Server shutdown.");
                    return;
                }
                if (packet.getCode() != ProtocolCodes.JOB_ASSIGN.getCodeKey()) break;

                Task task = Task.GetObject(packet.getData(), logger);
                System.out.println("Received - " + task); //TODO: Delete
                PacketUtils.SendEmptyPacket(ProtocolCodes.JOB_RECEIVED.getCodeKey(), output);

                Random random = new Random();
                for (int i = 0; i < (random.nextInt(3) + 2); i++) {
                    SendCurrentPosition(3);
                }

                PacketUtils.SendPacket(ProtocolCodes.JOB_COMPLETE.getCodeKey(), Task.GetBytes(task, logger), output);
                System.out.println("Completed - " + task + "\n");
            }
        }
    }

    /**
     * Performs the initial setup for the AGV.
     */
    private static boolean PerformSetup(String[] args) {
        try {
            InetAddress serverIP = InetAddress.getByName(args[0]);

            try {
                socket = new Socket(serverIP, 10753);

                try {
                    output = new ObjectOutputStream(socket.getOutputStream());
                    input = new ObjectInputStream(socket.getInputStream());

                    return true;
                } catch (IOException e) {
                    logger.log(Level.SEVERE, "Failed to create I/O streams." + e);
                    return false;
                }
            } catch (IOException e) {
                logger.log(Level.SEVERE, "Failed to create a Socket and establish a connection." + e);
                return false;
            }
        } catch (UnknownHostException e) {
            logger.log(Level.SEVERE, "Invalid server IP address or DNS name specified: \"" + args[0] + "\"." + e);
            return false;
        }
    }

    /**
     * Determines if a connection with the AGV Manager was successfully established.
     */
    private static boolean ClientHandshake(String[] args) {
        Packet packet = PacketUtils.ReceivePacket(input);
        if (packet == null) return false;
        if (packet.getCode() != ProtocolCodes.TEST.getCodeKey()) return false;
        System.out.println("\nReceived test packet."); //TODO: Delete

        if (!PacketUtils.SendPacket(ProtocolCodes.ACKNOWLEDGEMENT.getCodeKey(), args[1].getBytes(), output))
            return false;
        System.out.println("Sent acknowledgment packet.\n"); //TODO: Delete
        return true;
    }

    /**
     * Sends the current position of the AGV to the AGV Manager.
     */
    private static void SendCurrentPosition(long delay) {
        Random rand = new Random();
        Coordinates position = new Coordinates(rand.nextInt(100), rand.nextInt(100));
        PacketUtils.SendDelayedPacket(ProtocolCodes.JOB_UPDATE.getCodeKey(), Coordinates.GetBytes(position, logger), delay, output);
        System.out.println("Sent - " + position); //TODO: Delete
    }
}