package eapli.base.antlr4.src.domain;

import eapli.base.antlr4.src.domain.antlr4.QuestionnaireBaseVisitor;

public class EvalVisitor extends QuestionnaireBaseVisitor<String> {

}
