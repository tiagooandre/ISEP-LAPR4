package eapli.base.app.backoffice.console.presentation.questionnairemanagement;

import eapli.base.antlr4.src.application.QuestionnaireController;
import eapli.framework.io.util.Console;
import eapli.framework.presentation.console.AbstractUI;

import java.io.IOException;

public class QuestionnaireUI extends AbstractUI {

    private final QuestionnaireController questionnaireController = new QuestionnaireController();

    @Override
    protected boolean doShow() {
        String path = Console.readNonEmptyLine("Insert file path.", "Path required.");

        try {
            System.out.println("Path: " + path);
            questionnaireController.questionnaireValidation(path);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return true;
    }

    @Override
    public String headline() {
        return "questionnaire";
    }
}
