import domain.Coordinates;
import domain.Packet;
import domain.ProtocolCodes;
import domain.Task;
import utils.DBUtils;
import utils.PacketUtils;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.logging.Level;
import java.util.logging.Logger;

public class TcpThread implements Runnable {
    private final long connectionID;
    private final Socket socket;
    private final Logger logger = Logger.getLogger(TcpThread.class.getName());
    private ObjectOutputStream output;
    private ObjectInputStream input;
    private int taskCounter = 0;
    private String agvID;

    public TcpThread(long connectionID, Socket socket) {
        this.connectionID = connectionID;
        this.socket = socket;
    }

    public void run() {
        System.out.println("\nNew client connection - " + socket.getInetAddress().getHostAddress() + ":" + socket.getPort());

        if (!PerformSetup() || !ServerHandshake()) return;

        while (true) {
            if (!AssignTask(output)) ThreadShutdown("Failed to assign task.");

            while (true) {
                Packet packet = PacketUtils.ReceivePacket(input);
                if (packet == null) {
                    System.out.println("Client disconnected.");
                    return;
                }

                if (packet.getCode() == ProtocolCodes.JOB_COMPLETE.getCodeKey()) {
                    System.out.println("Client completed - " + Task.GetObject(packet.getData(), logger) + "\n");
                    UpdateState("free");
                    break;
                }

                Coordinates position = Coordinates.GetObject(packet.getData(), logger);
                if (position != null) {
                    System.out.println("Received - " + position);
                    UpdateCoordinates(position);
                }
            }
            PacketUtils.Sleep(10);
        }
    }

    /**
     * Performs the initial setup for the AGV Manager thread.
     */
    private boolean PerformSetup() {
        try {
            output = new ObjectOutputStream(socket.getOutputStream());
            input = new ObjectInputStream(socket.getInputStream());
            return true;
        } catch (IOException e) {
            ThreadShutdown("Failed to create I/O streams." + e);
            return false;
        }
    }

    /**
     * Determines if a connection with the AGV was successfully established.
     */
    private boolean ServerHandshake() {
        if (!PacketUtils.SendEmptyPacket(ProtocolCodes.TEST.getCodeKey(), output)) return false;
        System.out.println("\nSent test packet."); //TODO: Delete

        Packet packet = PacketUtils.ReceivePacket(input);
        if (packet == null) return false;
        if (packet.getCode() != ProtocolCodes.ACKNOWLEDGEMENT.getCodeKey()) return false;

        agvID = new String(packet.getData(), StandardCharsets.UTF_8);
        System.out.println("Received acknowledgment packet.\n"); //TODO: Delete
        return true;
    }

    /**
     * Assigns a task to the AGV and checks if it received it.
     */
    private boolean AssignTask(ObjectOutputStream output) {
        Task task = new Task("Task number " + taskCounter++);
        PacketUtils.SendPacket(ProtocolCodes.JOB_ASSIGN.getCodeKey(), Task.GetBytes(task, logger), output);
        System.out.println("Sent - " + task); //TODO: Delete

        Packet packet = PacketUtils.ReceivePacket(input);
        if (packet == null) return false;
        if (packet.getCode() != ProtocolCodes.JOB_RECEIVED.getCodeKey()) return false;
        System.out.println("Client accepted - " + task); //TODO: Delete
        UpdateState("busy");
        return true;
    }

    /**
     * Prints an error message and tells the Main thread to remove this connection.
     */
    private void ThreadShutdown(String message) {
        Server.RemoveConnection(connectionID);
        logger.log(Level.SEVERE, message);
    }

    private void UpdateCoordinates(Coordinates coordinates) {
        DBUtils.ExecuteQuery("UPDATE AGVDOCK SET CURRENTPOSX = " + coordinates.getxPos() + ", CURRENTPOSY = " + coordinates.getyPos() + " WHERE ID = '" + agvID + "'");
    }

    private void UpdateState(String state) {
        DBUtils.ExecuteQuery("UPDATE AGVDOCK SET STATE = '" + state + "' WHERE ID = '" + agvID + "'");
    }
}