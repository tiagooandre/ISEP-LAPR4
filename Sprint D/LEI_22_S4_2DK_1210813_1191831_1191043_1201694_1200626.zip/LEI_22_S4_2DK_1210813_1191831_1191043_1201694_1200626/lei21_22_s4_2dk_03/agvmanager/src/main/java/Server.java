import domain.AGVManager;

public class Server {
    public static void main(String[] args) {
        new AGVManager().run();
    }
}