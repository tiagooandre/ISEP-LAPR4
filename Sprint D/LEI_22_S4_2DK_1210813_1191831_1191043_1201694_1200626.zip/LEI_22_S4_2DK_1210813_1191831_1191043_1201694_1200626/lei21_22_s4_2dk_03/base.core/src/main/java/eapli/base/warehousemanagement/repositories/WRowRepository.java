package eapli.base.warehousemanagement.repositories;

import eapli.base.warehousemanagement.domain.WRow;
import eapli.framework.domain.repositories.DomainRepository;

public interface WRowRepository extends DomainRepository<Long, WRow> {
}