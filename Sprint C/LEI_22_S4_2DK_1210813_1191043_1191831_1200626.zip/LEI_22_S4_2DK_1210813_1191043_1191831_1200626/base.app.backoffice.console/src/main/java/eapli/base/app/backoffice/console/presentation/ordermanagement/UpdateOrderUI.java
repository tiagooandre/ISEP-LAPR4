package eapli.base.app.backoffice.console.presentation.ordermanagement;

import eapli.base.customermanagement.application.RegisterCustomerController;
import eapli.base.customermanagement.domain.Customer;
import eapli.base.itemorderedmanagement.domain.ItemOrdered;
import eapli.base.ordermanagement.application.OrderController;
import eapli.base.ordermanagement.domain.*;
import eapli.base.productmanagement.application.CategoryDefineController;
import eapli.base.productmanagement.application.ListProductController;
import eapli.base.productmanagement.domain.Product;
import eapli.base.usermanagement.application.AddUserController;
import eapli.framework.io.util.Console;
import eapli.framework.presentation.console.AbstractUI;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Random;

public class UpdateOrderUI extends AbstractUI {
    private final OrderController orderController = new OrderController();

    @Override
    protected boolean doShow() {
        String status = Console.readNonEmptyLine("\nEnter the status for the Order: ", "Status required.");
        List<NewOrder> newOrderList = orderController.findByStatus(status);
        orderController.listAllOrders(newOrderList);

        String orderID = Console.readNonEmptyLine("\nChoose the order ID: ", "Order ID required.");
        NewOrder newOrder = orderController.findByID(orderID);

        System.out.println("Your order will be now dispatched for customer delivery ...");
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        System.out.println(orderController.updateOrder(newOrder));
        
        return true;
    }

    @Override
    public String headline() {
        return "Update a Order's status to DISPATCHED_FOR_CUSTOMER_DELIVERY";
    }
}
