package domain;

import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Task implements Serializable {
    private final String msg;

    public Task(String msg) {
        this.msg = msg;
    }

    public String getMsg() {
        return msg;
    }

    @Override
    public String toString() {
        return this.msg;
    }

    public static byte[] GetBytes(Task task, Logger logger) {
        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            ObjectOutputStream oos = new ObjectOutputStream(bos);
            oos.writeObject(task);
            oos.flush();
            return bos.toByteArray();
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Failed to convert from Task object into a Byte array." + e);
            return null;
        }
    }

    public static Task GetObject(byte[] data, Logger logger) {
        try {
            ByteArrayInputStream bis = new ByteArrayInputStream(data);
            ObjectInputStream ois = new ObjectInputStream(bis);
            return (Task) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            logger.log(Level.SEVERE, "Failed to convert from Byte array into a Task object." + e);
            return null;
        }
    }
}