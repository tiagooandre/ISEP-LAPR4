import domain.AGVDigitalTwin;

public class Client {
    public static void main(String[] args) {
        new AGVDigitalTwin().run(args);
    }
}