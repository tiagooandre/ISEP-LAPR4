** Tiago Pinto [1200626](./)** 
===============================


### Índice das Funcionalidade Desenvolvidas ###


| Sprint | Funcionalidade     |
|--------|--------------------|
| **B**  | [US1003](/docs/Sprint%20B/US1003) |
| **B**  | [US1004](/docs/Sprint%20B/US1004) |
| **B**  | [US1005](/docs/Sprint%20B/US1005) |
| **B**  | [US1900](/docs/Sprint%20B/US1900) |
| **C**  | [US2003](/docs/Sprint%20C/US2003) |
| **C**  | [US2004](/docs/Sprint%20C/US2004) |
| **C**  | [US3000](/docs/Sprint%20C/US3000) |
| **C**  | [US3001](/docs/Sprint%20C/US3001) |
| **D**  | [US1006](/docs/Sprint%20D/US1006) |
| **D**  | [US3501](/docs/Sprint%20D/US3501) |
| **D**  | [US3002](/docs/Sprint%20D/US3002) |