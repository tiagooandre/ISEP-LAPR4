package controller;

import utils.Utils;

public class UtilsController {

    public void sleepSeconds(long seconds) {
        Utils.sleepSeconds(seconds);
    }

    public void sleepMilliseconds(long milliseconds) {
        Utils.sleepMilliseconds(milliseconds);
    }
}