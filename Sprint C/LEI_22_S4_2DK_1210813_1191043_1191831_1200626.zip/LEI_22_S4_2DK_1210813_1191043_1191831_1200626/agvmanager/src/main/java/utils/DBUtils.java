package utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DBUtils {

    private static final Logger logger = Logger.getLogger(DBUtils.class.getName());
    private static final String DB_URL = "jdbc:h2:tcp://vsgate-s2.dei.isep.ipp.pt:10141/db";
    private static final String DB_USERNAME = "";
    private static final String DB_PASSWORD = "fcXPDZ5tuxxe";

    public static Connection CreateConnection() {
        try {
            Class.forName("org.h2.Driver");
            try {
                return DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    public static boolean ExecuteQuery(String query) {
        Connection connection = DBUtils.CreateConnection();

        try (Statement statement = connection.createStatement()) {
            statement.executeUpdate(query);
            return true;
        } catch (SQLException e) {
            logger.log(Level.WARNING, "Failed to execute the following query: \"" + query + "\"" + e);
            return false;
        }
    }
}