package eapli.base.app.other.console;

/**
 * Created by Nuno Bettencourt [NMB] on 03/04/16.
 */
public class BaseBackofficeTest {

}
