package domain;

import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Coordinates implements Serializable {
    private final int xPos;
    private final int yPos;

    public Coordinates(int xPos, int yPos) {
        this.xPos = xPos;
        this.yPos = yPos;
    }

    public int getxPos() {
        return xPos;
    }

    public int getyPos() {
        return yPos;
    }

    @Override
    public String toString() {
        return "Coordinates[" + xPos + "][" + yPos + "]";
    }

    public static byte[] GetBytes(Coordinates coordinates, Logger logger) {
        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            ObjectOutputStream oos = new ObjectOutputStream(bos);
            oos.writeObject(coordinates);
            oos.flush();
            return bos.toByteArray();
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Failed to convert from Coordinates object into a Byte array." + e);
            return null;
        }
    }

    public static Coordinates GetObject(byte[] data, Logger logger) {
        try {
            ByteArrayInputStream bis = new ByteArrayInputStream(data);
            ObjectInputStream ois = new ObjectInputStream(bis);
            return (Coordinates) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            logger.log(Level.SEVERE, "Failed to convert from Byte array into a Coordinates object." + e);
            return null;
        }
    }
}