package utils;

import domain.Packet;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;

public class PacketUtils {

    private static final Logger logger = Logger.getLogger(PacketUtils.class.getName());

    /**
     * Sends a packet through the output stream.
     */
    public static boolean SendPacket(byte code, byte[] data, ObjectOutputStream output) {
        Packet packet = new Packet((byte) 0, code, data);
        try {
            output.writeObject(packet);
            return true;
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Failed to send the packet." + e);
            return false;
        }
    }

    /**
     * Sends a packet through the output stream with a specified delay.
     */
    public static boolean SendDelayedPacket(byte code, byte[] data, long delay, ObjectOutputStream output) {
        Sleep(delay);
        Packet packet = new Packet((byte) 0, code, data);
        try {
            output.writeObject(packet);
            return true;
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Failed to send the packet." + e);
            return false;
        }
    }

    /**
     * Sends a packet through the output stream.
     */
    public static boolean SendEmptyPacket(byte code, ObjectOutputStream output) {
        Packet packet = new Packet((byte) 0, code, null);
        try {
            output.writeObject(packet);
            return true;
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Failed to send the packet." + e);
            return false;
        }
    }

    /**
     * Receives a packet through the input stream.
     */
    public static Packet ReceivePacket(ObjectInputStream input) {
        try {
            return (Packet) input.readObject();
        } catch (IOException | ClassNotFoundException e) {
            logger.log(Level.SEVERE, "Failed to read packet from the input stream." + e);
            return null;
        }
    }

    /**
     * Stops a threads for the specified amount of seconds
     */
    public static void Sleep(long seconds) {
        try {
            Thread.sleep(seconds * 1000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
}