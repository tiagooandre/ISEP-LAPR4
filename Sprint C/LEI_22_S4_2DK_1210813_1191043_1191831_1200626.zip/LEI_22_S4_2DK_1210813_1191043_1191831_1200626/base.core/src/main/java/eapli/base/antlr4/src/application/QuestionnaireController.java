package eapli.base.antlr4.src.application;

import eapli.base.antlr4.src.domain.EvalVisitor;
import eapli.base.antlr4.src.domain.antlr4.QuestionnaireLexer;
import eapli.base.antlr4.src.domain.antlr4.QuestionnaireParser;
import org.antlr.v4.runtime.ANTLRInputStream;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.tree.ParseTree;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class QuestionnaireController {
    public boolean questionnaireValidation (String path) throws IOException {
        FileInputStream fis = new FileInputStream(new File("Questionnaire1.txt"));
        QuestionnaireLexer lexer = new QuestionnaireLexer(new ANTLRInputStream(fis));
        CommonTokenStream tokens = new CommonTokenStream(lexer);
        QuestionnaireParser parser = new QuestionnaireParser(tokens);
        ParseTree tree = parser.start(); // parse
        EvalVisitor eval = new EvalVisitor();
        eval.visit(tree);

        return true;
    }
}
