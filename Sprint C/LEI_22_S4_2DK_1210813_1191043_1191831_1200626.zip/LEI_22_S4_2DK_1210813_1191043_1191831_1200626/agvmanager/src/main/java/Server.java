import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;

public class Server {
    private static final Map<Long, Thread> clientConnections = new HashMap<>();

    public static void main(String[] args) {
        long connectionCounter = 0;

        System.out.println("\nInitialized AGV Manager.");

        try (ServerSocket serverSocket = new ServerSocket(2223)) {
            while (true) {
                Socket clientsSocket = serverSocket.accept();
                clientConnections.put(connectionCounter, new Thread(new TcpThread(connectionCounter, clientsSocket)));
                clientConnections.get(connectionCounter++).start();
            }
        } catch (IOException e) {
            System.out.println("Failed to open the server socket");
            throw new RuntimeException(e);
        }
    }

    public static void RemoveConnection(long connectionID) {
        clientConnections.remove(connectionID);
    }
}