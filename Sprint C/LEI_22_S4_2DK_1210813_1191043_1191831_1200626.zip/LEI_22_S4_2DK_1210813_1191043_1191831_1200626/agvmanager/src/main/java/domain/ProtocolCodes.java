package domain;

public enum ProtocolCodes {
    TEST((byte) 0),
    DISCONNECT((byte) 1),
    ACKNOWLEDGEMENT((byte) 2),
    JOB_ASSIGN((byte) 4),
    JOB_RECEIVED((byte) 5),
    JOB_UPDATE((byte) 6),
    JOB_COMPLETE((byte) 7);

    private final byte codeKey;

    ProtocolCodes(byte codeKey) {
        this.codeKey = codeKey;
    }

    public byte getCodeKey() {
        return codeKey;
    }
}